#pragma once
#include <stdint.h>
#include <vector>

namespace std {

    using bytearray = vector<uint8_t>;

}
